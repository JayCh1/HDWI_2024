#!/bin/bash

# A. Srock, 6/17
# A. Srock, 7/18 -- updated for new website rollout, new way to use this file, etc...

echo "Currently updating plots. Check dates carefully." > hdwstatus.txt
